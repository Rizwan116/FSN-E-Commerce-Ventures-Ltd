 
function Navbar() {
  return (
    <div className="navbar-section">
    <div className="navbar-container">
      
      
        <div>Shop</div>
        <div>About Us</div>
        <div>Blog</div>
    
      
    </div>
  </div>
  );
}

export default Navbar;
