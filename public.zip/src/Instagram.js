function Insta() {

    return (
     <p>Instagram</p>
    );
  }
  
  export default Insta;