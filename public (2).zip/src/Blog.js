function Blog() {
    return <h1>Our Blog</h1>;
  }
  
  export default Blog;
  