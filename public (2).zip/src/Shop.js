function Shop() {
    return <h1>Welcome to the Shop Page</h1>;
  }
  
  export default Shop;
  