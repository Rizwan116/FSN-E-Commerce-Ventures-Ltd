function Accessibility() {
    return <h1>My Accessibility Page</h1>;
  }
  
  export default Accessibility;
  