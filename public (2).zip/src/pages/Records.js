function Records() {
    return <h1>My Records Page</h1>;
  }
  
  export default Records;
  