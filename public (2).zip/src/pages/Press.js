function Press() {
    return <h1>My Press Page</h1>;
  }
  
  export default Press;
  