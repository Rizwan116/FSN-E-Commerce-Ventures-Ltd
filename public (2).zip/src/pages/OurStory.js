function OurStory() {
    return <h1>My OurStory Page</h1>;
  }
  
  export default OurStory;
  