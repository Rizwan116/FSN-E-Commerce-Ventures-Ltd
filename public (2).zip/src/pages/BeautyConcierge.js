function BeautyConcierge() {
    return <h1>My BeautyConcierge Page</h1>;
  }
  
  export default BeautyConcierge;
  