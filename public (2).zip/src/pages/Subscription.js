function Subscription() {
    return <h1>My Subscription Page</h1>;
  }
  
  export default Subscription;
  