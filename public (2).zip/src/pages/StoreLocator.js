function StoreLocator() {
    return <h1>My StoreLocator Page</h1>;
  }
  
  export default StoreLocator;
  