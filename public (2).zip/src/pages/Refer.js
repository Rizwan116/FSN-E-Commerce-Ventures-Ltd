function Refer() {
    return <h1>My Refer Page</h1>;
  }
  
  export default Refer;
  