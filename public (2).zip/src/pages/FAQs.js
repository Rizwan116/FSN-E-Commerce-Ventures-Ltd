function FAQs() {
    return <h1>My FAQs Page</h1>;
  }
  
  export default FAQs;
  