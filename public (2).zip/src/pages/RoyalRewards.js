function RoyalRewards() {
    return <h1>My RoyalRewards Page</h1>;
  }
  
  export default RoyalRewards;
  