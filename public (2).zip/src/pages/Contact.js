function Contact() {
    return <h1>My Contact Page</h1>;
  }
  
  export default Contact;
  