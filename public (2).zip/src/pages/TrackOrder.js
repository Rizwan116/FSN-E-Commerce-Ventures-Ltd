const TrackOrder = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h2>📦 Track Your Order</h2>
      <p>Order tracking details coming soon...</p>
    </div>
  );
};

export default TrackOrder;
